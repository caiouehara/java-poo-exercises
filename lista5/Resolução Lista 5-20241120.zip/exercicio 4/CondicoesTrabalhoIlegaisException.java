public class CondicoesTrabalhoIlegaisException extends Exception {
    CondicoesTrabalhoIlegaisException(String messageString) {
        super(messageString);
    }
}

