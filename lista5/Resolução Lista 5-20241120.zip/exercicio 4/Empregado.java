public interface Empregado {
    double getValorPagamento() throws CondicoesTrabalhoIlegaisException;
} 
