public interface Empregado {
    double getValorPagamento();
} 
